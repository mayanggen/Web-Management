<!DOCTYPE HTML>
<html>
<head>
	<title>Activity # 4</title>
	<style type = "text/css">
		body{
			font-family:verdana;
			font-size:12px;
		}
		td{
			background-color:pink;
			color:green;
		}
		#Size{
			width:90%;
		}
	</style>
</head>
<body style ="background-color:#eeeeee;">
	<form action = "payroll2.php" method = "POST">
		<table border = "0" cellpadding ="10" cellspacing ="2" align = "center" width ="400">
			<tr style ="text-align:center;">
				<td colspan = "2"><b>Activity # 4</b></td>
			</tr>
			<tr>
				<td>Employee Name:</td>
				<td><input type ="text" name ="name" id =""></td>
			</tr>
			<tr>
				<td>Total Days of Work:</td>
				<td><input type ="text" name ="total_days" id =""></td>
			</tr>
			<tr>
				<td>Daily Rate:</td>
				<td><input type ="text" name ="daily_rate" id =""></td>
			</tr>
			<tr>
				<td>Cash Advance:</td>
				<td><input type ="text" name ="cash_advance" id =""></td>
			</tr>
			<tr style = "text-align:right;">
				<td colspan ="2"><input type ="submit" name ="submit" value  = "Compute" style = "width:100px;"a></td>
			</tr>
		</table>
	</form>
</body>

</html>