<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee Payroll</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            margin: 20px;
        }
        table {
            margin: 0 auto;
            border-collapse: collapse;
            width: 60%;
            background-color: #ffffff;
            border: 1px solid #ddd;
        }
        td, th {
            border: 1px solid #ddd;
            padding: 8px;
        }
        th {
            background-color: #f4f4f4;
        }
        .right-align {
            text-align: right;
        }
        .bold {
            font-weight: bold;
        }
        hr {
            border: 0;
            border-top: 1px solid #ddd;
            margin: 10px 0;
        }
    </style>
</head>
<body>

<?php 
// Ensure data is safely handled
$name = htmlspecialchars($_POST['name'] ?? 'N/A');
$total_days = (float)($_POST['total_days'] ?? 0);
$daily_rate = (float)($_POST['daily_rate'] ?? 0);
$cash_advance = (float)($_POST['cash_advance'] ?? 0);

$gross = $daily_rate * $total_days;
$tax = $gross * 0.05;
$sss = $gross * 0.02;
$philhealth = $gross * 0.03;
$pag_ibig = 50;
$deductions = $cash_advance + $tax + $sss + $philhealth + $pag_ibig;
$net = $gross - $deductions;
?>

<h1>Employee Payroll Details</h1>

<table border="10" cellpadding="4" cellspacing="2" align="center" width="350">
    <tr>
        <td width="150">Employee Name:</td>
        <td><?php echo htmlspecialchars($name); ?></td>
    </tr>
    <tr>
        <td>Daily Rate:</td>
        <td><?php echo number_format($daily_rate, 2); ?></td>
    </tr>
    <tr>
        <td>Days of Work:</td>
        <td><?php echo number_format($total_days); ?></td>
    </tr>
    <tr>
        <td colspan="2"><hr></td>
    </tr>
    <tr>
        <td class="bold">GROSS PAY:</td>
        <td class="right-align bold"><?php echo number_format($gross, 2); ?></td>
    </tr>
    <tr>
        <td colspan="2"><b>DEDUCTIONS:</b></td>
    </tr>
    <tr class="right-align">
        <td>Tax 5%:</td>
        <td><?php echo number_format($tax, 2); ?></td>
    </tr>
    <tr class="right-align">
        <td>SSS 2%:</td>
        <td><?php echo number_format($sss, 2); ?></td>
    </tr>
    <tr class="right-align">
        <td>Philhealth 3%:</td>
        <td><?php echo number_format($philhealth, 2); ?></td>
    </tr>
    <tr class="right-align">
        <td>Pagibig P50:</td>
        <td><?php echo number_format($pag_ibig, 2); ?></td>
    </tr>
    <tr class="right-align">
        <td>Cash Advance:</td>
        <td><?php echo number_format($cash_advance, 2); ?></td>
    </tr>
    <tr>
        <td colspan="2"><hr></td>
    </tr>
    <tr>
        <td class="bold">TOTAL DEDUCTIONS:</td>
        <td class="right-align bold"><?php echo number_format($deductions, 2); ?></td>
    </tr>
    <tr>
        <td class="bold">NET PAY:</td>
        <td class="right-align bold"><?php echo number_format($net, 2); ?></td>
    </tr>
</table>

</body>
</html>
